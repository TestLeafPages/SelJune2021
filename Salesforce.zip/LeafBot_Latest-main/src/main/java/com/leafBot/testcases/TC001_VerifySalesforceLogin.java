package com.leafBot.testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.leafBot.pages.LoginPage;
import com.leafBot.testng.api.base.ProjectSpecificMethods;

public class TC001_VerifySalesforceLogin extends ProjectSpecificMethods{	

	@BeforeTest
	public void setValues() {
		testCaseName = "Verify Login";
		testDescription = "Login testCase using positive data";
		nodes = "Login";
		authors = "Hari";
		category = "Smoke";
		
	}

	@Test
	public void verifyLogin() {
		new LoginPage(driver, node)
		.enterUserName(prop.getProperty("username"))
		.enterPassword(prop.getProperty("password"))
		.clickLogin()
		.verifyHomepage();
	}


}





