package hooks;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;

import io.github.bonigarcia.wdm.WebDriverManager;
import utils.ReadExcel;

public class TestNgHooks {
	
	// I wanted to have single browser reference 
	// Can't I run in parallel? Yes, you cannot run. 
	public RemoteWebDriver driver;
	public String excelFileName;
	
	public Properties prop;
	
	// launch the browser
	@Parameters({"language"})
	@BeforeMethod
	public void setUp(String lang) throws IOException {
		//properties file set up
		FileInputStream fis = new FileInputStream("./src/main/resources/"+lang+".properties");
		prop = new Properties();
		prop.load(fis);
			
		
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.get(prop.getProperty("url"));
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		
		
	}
	
	// close the browser
	@AfterMethod
	public void tearDown() {
		driver.close();
	}
	
	@DataProvider(name = "fetchData", indices = 0)
	public String[][] sendData() throws IOException {
		
		return ReadExcel.readData(excelFileName);
	}
	

}
