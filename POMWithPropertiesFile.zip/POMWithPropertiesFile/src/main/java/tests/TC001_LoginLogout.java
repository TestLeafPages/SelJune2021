package tests;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import hooks.TestNgHooks;
import pages.HomePage;
import pages.LoginPage;

public class TC001_LoginLogout extends TestNgHooks{
	
	@BeforeTest
	public void setFileName() {
		excelFileName = "Login";

	}
	
	@Test(dataProvider = "fetchData")
	public void loginLogout(String uName, String pWord) throws InterruptedException {
		System.out.println(driver);
		new LoginPage(driver,prop)
			.typeUserName(prop.getProperty("username"))
			.typePassword(prop.getProperty("password"))
			.clickLogin()
			.clickLogout();
		
	}

}

