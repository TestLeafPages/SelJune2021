package pages;

import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import hooks.TestNgHooks;

public class ViewLeadPage extends TestNgHooks {
	public ViewLeadPage(RemoteWebDriver driver, Properties prop) {
		
		this.driver  = driver;
		this.prop = prop;
		
	}

	public ViewLeadPage verifyFirstName(String firstName) {
		String fName = driver.findElement(By.id("viewLead_firstName_sp")).getText();
		if (fName.equals(firstName))
			System.out.println("All good");
		else
			System.err.println("Something went wrong");

		return this;
	}

}
