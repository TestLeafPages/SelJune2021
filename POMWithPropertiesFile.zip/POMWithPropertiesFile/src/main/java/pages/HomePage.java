package pages;

import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import hooks.TestNgHooks;

public class HomePage extends TestNgHooks {

	public HomePage(RemoteWebDriver driver, Properties prop) {
		
		this.driver  = driver;
		this.prop = prop;
		
	}

	public LoginPage clickLogout() {
		driver.findElement(By.xpath("//input[@value='Logout']")).click();
		return new LoginPage(driver,prop);
	}

	public MyHomePage clickCrm() {
		driver.findElement(By.linkText("CRM/SFA")).click();
		return new MyHomePage(driver,prop);
	}

}
