package pages;

import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import hooks.TestNgHooks;

public class MyLeadsPage extends TestNgHooks {

	public MyLeadsPage(RemoteWebDriver driver, Properties prop) {
		
		this.driver  = driver;
		this.prop = prop;
		
	}

	public CreateLeadPage clickCreateLeadMenu() {
		driver.findElement(By.linkText(prop.getProperty("MyLeadsPage.CreateLead.LinkText"))).click();
		return new CreateLeadPage(driver,prop);
	}

}
