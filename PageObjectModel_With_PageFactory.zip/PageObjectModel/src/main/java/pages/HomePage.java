package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.PageFactory;

import hooks.TestNgHooks;

public class HomePage extends TestNgHooks {

	public HomePage(RemoteWebDriver driver) {
		this.driver  = driver;
		PageFactory.initElements(driver, this);
	}

	public LoginPage clickLogout() {
		driver.findElement(By.xpath("//input[@value='Logout']")).click();
		return new LoginPage(driver);
	}

	public MyHomePage clickCrm() {
		driver.findElement(By.linkText("CRM/SFA")).click();
		return new MyHomePage(driver);
	}

}
