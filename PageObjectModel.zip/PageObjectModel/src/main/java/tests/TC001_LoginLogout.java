package tests;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import hooks.TestNgHooks;
import pages.HomePage;
import pages.LoginPage;

public class TC001_LoginLogout extends TestNgHooks{
	
	@BeforeTest
	public void setFileName() {
		excelFileName = "Login";

	}
	
	@Test(dataProvider = "fetchData")
	public void loginLogout(String uName, String pWord) {
		
		new LoginPage()
			.typeUserName(uName)
			.typePassword(pWord)
			.clickLogin()
			.clickLogout();
		
	}

}

